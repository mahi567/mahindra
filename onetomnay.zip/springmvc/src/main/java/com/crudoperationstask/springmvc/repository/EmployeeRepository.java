package com.crudoperationstask.springmvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crudoperationstask.springmvc.model.EmployeeInfo;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeInfo,Integer> {

}
