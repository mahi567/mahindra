package com.crudoperationstask.springmvc.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crudoperationstask.springmvc.model.StudentInfo;
import com.crudoperationstask.springmvc.service.StudentServiceImpl;

@RestController
@CrossOrigin("*")
public class StudentController {
	
	
	@Autowired
	private StudentServiceImpl serviceimpl;
	
	@PostMapping(value="saveStudent")
	public ResponseEntity<String> saveStudent(@RequestBody StudentInfo info) {
		if(info.getAddress()==null) {
				return new ResponseEntity<>("address must be given",HttpStatus.NOT_FOUND);
			
		}
		if(info.getEmail()==null) {
			return new ResponseEntity<>("Email must be given",HttpStatus.BAD_REQUEST);
		
	}	
		if(info.getName()==null) {
			return new ResponseEntity<>("Name must be given",HttpStatus.NOT_IMPLEMENTED);
		
		}info.getEmployeeinfo();
		serviceimpl.saveStudent(info);
		
		return new ResponseEntity<>(info.toString(),HttpStatus.CREATED);
		
		
	}
	@GetMapping(value="getAllStudents")
	public Set<StudentInfo> findAllStudents() {
		
		return (Set<StudentInfo>) serviceimpl.findAllStudents();
		
	}
	@PutMapping(value="updateStudent")
	public StudentInfo updateStudent(@RequestBody StudentInfo info) {
		
		serviceimpl.updateStudent(info);
	    return info;
	}
	@DeleteMapping(value="deleteStudent")
	public String deleteStudent(@RequestParam Long id) {
		serviceimpl.deleteStudent(id);
		return "student deleted";
		
	}
}
