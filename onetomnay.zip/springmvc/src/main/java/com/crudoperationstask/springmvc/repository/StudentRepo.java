package com.crudoperationstask.springmvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crudoperationstask.springmvc.model.StudentInfo;

@Repository
public interface StudentRepo extends JpaRepository<StudentInfo,Long> {

	//StudentInfo save(StudentInfo info);

	

}