package com.crudoperationstask.springmvc.dto;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.crudoperationstask.springmvc.model.EmployeeInfo;

public interface EmployeeInterface {
	
public EmployeeInfo saveEmployee(EmployeeInfo info);
	
	public EmployeeInfo updateEmployee(EmployeeInfo info);
	
	public void deleteEmployee(Integer id);
	
	public List<EmployeeInfo> findAllEmployees();

	public EmployeeInfo saveEmployee(ResponseEntity<String> info);


}
