package com.crudoperationstask.springmvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employeet")
public class EmployeeInfo {
	

		private int eid;
		private int eins;
		private int sal;
//		public Object getEins;
//		public Object getSal;
		
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		public int getEid() {
			return eid;
		}
		
		public void setEid(int eid) {
			this.eid = eid;
		}
		
		public int getEins() {
			return eins;
		}
		
		public void setEins(int eins) {
			this.eins = eins;
		}
		
		public int getSal() {
			return sal;
		}
		
		public void setSal(int sal) {
			this.sal = sal;
		}

		public EmployeeInfo(int eid, int eins, int sal) {
			super();
			this.eid = eid;
			this.eins = eins;
			this.sal = sal;
		}
		
		@Override
	public String toString() {
		return "EmployeeInfo [eid=" + eid + ", eins=" + eins + ", sal=" + sal + "]";
	}
		
		 
}
