package com.crudoperationstask.springmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

public class SprinMvcApplicationTests {

	@SpringBootTest
	class CrudoperationsexampleApplicationTests {

		@Test
		void contextLoads() {
		}
	}
}
