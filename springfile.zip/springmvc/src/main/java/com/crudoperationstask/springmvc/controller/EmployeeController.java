//package com.crudoperationstask.springmvc.controller;
//
//import java.util.List;
//import java.util.Set;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.crudoperationstask.springmvc.dto.StudentInteface;
//import com.crudoperationstask.springmvc.model.EmployeeInfo;
//import com.crudoperationstask.springmvc.service.EmployeeServiceImpl;
//
//@RestController
//@CrossOrigin("*")
//public class EmployeeController{
//	
//	@Autowired
//	private StudentInteface studentInterface;
//	
//	@Autowired
//	EmployeeServiceImpl employeeService;
//	
//	@PostMapping(value="saveEmployee")
//	public ResponseEntity<String> saveEmployee(@RequestBody EmployeeInfo info) {
////		if(info.getEins.equals(null)) {
////				return new ResponseEntity<>("?Insurance must be given",HttpStatus.NOT_FOUND);
////			
////		}
////		if(info.getSal.equals(null)) {
////			return new ResponseEntity<>("salary must be given",HttpStatus.BAD_REQUEST);
////		
////	}	
//		employeeService.saveEmployee(info);
//		
//		return new ResponseEntity<>(info.toString(),HttpStatus.CREATED);
//		
//		
//	}
//	@GetMapping("getAllEmployees")
//	public List<EmployeeInfo> findAllStudents() {
//		
//		return (List<EmployeeInfo>) employeeService.findAllEmployees();
//		
//	}
//	@PutMapping(value="updateEmployee")
//	public EmployeeInfo updateStudent(@RequestBody EmployeeInfo employee) {
//		
//		employeeService.updateEmployee(employee);
//	    return employee;
//	}
//	@DeleteMapping(value="deleteEmployee")
//	public String deleteEmployee(@RequestParam Integer id) {
//		employeeService.deleteEmployee(id);
//		return "Employee deleted";
//		
//	}
//}
