package com.crudoperationstask.springmvc.model;

public class ServiceStatus {

	private String Status;
	private String Message;
	private String Result;
	
	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}


	public String getMessage() {
		return Message;
	}


	public void setMessage(String message) {
		Message = message;
	}


	public String getResult() {
		return Result;
	}


	public void setResult(String result) {
		Result = result;
	}
}
