package com.crudoperationstask.springmvc.dto;

import java.util.List;
import java.util.Set;

import org.springframework.http.ResponseEntity;
import com.crudoperationstask.springmvc.model.EmployeeInfo;

public interface EmployeeInterface {
	
public EmployeeInfo saveEmployee(EmployeeInfo info);
	
	public EmployeeInfo updateEmployee(EmployeeInfo info);
	
	public void deleteEmployee(Integer id);
	
	public List<EmployeeInfo> findAllEmployees();

	public EmployeeInfo saveEmployee(ResponseEntity<String> info);

	//public Integer  max(Integer sal);


}
