package com.crudoperationstask.springmvc.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.crudoperationstask.springmvc.model.EmployeeInfo;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeInfo,Integer> {

		@Query(value="insert into employee_info values((?,?),(?,?))",nativeQuery=true)
	public EmployeeInfo saveEmployee(EmployeeInfo info);
		
		@Query(value="update employee_info set((?,?),(?,?)) where eid between ? and ?",nativeQuery=true)
		public EmployeeInfo updateEmployee(EmployeeInfo info);
	
		@Query(value="delete from employee_info where eid between ? or ?",nativeQuery=true)
     	public void deleteEmployee(Integer id);
		
		@Query(value="select * from employee_info ",nativeQuery=true)
		public List<EmployeeInfo> findAllEmployees();
		
		@Query(value="select max(sal) form employee_info",nativeQuery = true)
		public  Integer max(Integer sal);
}