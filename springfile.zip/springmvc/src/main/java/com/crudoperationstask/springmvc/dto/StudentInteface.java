package com.crudoperationstask.springmvc.dto;

import java.util.List;
import java.util.Set;

import org.springframework.http.ResponseEntity;

import com.crudoperationstask.springmvc.model.StudentInfo;

public interface StudentInteface {

	public StudentInfo saveStudent(StudentInfo info);
	
	public StudentInfo updateStudent(StudentInfo info);
	
	public void deleteStudent(Long id);
	
	public List<StudentInfo> findAllStudentsByName();

	public List<StudentInfo> findAllStudents();
	
	public StudentInfo saveStudent(ResponseEntity<String> info);

	
}
