package com.crudoperationstask.springmvc.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.crudoperationstask.springmvc.dto.StudentInteface;
import com.crudoperationstask.springmvc.model.StudentInfo;
import com.crudoperationstask.springmvc.repository.StudentRepo;

@Service
public  class StudentServiceImpl implements StudentInteface{
	
	@Autowired
	private StudentRepo student;
	
	@Override
	public StudentInfo saveStudent(StudentInfo info) {
	
		return student.save(info);
	}

	@Override
	public StudentInfo updateStudent(StudentInfo info) {
		
		return student.save(info);
	}

	@Override
	public void deleteStudent(Long id) {
		student.deleteById(id);
		
	}

	@Override
	public List<StudentInfo> findAllStudentsByName() {
		
		return (List<StudentInfo>) student.findAllStudentsByName();
	}

	@Override
	public List<StudentInfo> findAllStudents() {
		
		return (List<StudentInfo>) student.findAllStudents();
	}
	@Override
	public StudentInfo saveStudent(ResponseEntity<String> info) {
		
		return null;
	}

	

}
