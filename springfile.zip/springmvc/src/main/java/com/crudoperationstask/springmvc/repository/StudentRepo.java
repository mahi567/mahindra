package com.crudoperationstask.springmvc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.crudoperationstask.springmvc.model.StudentInfo;

@Repository
public interface StudentRepo extends JpaRepository<StudentInfo,Long> {

		@Query(value="insert into student_info values(?,?,?)",nativeQuery=true)
	    public StudentInfo saveStudent(StudentInfo info);
		
		@Query(value="update student_info set name=?,email=?,address=? where id=?",nativeQuery=true)
		public StudentInfo updateStudent(StudentInfo info);
		
		@Query(value="delete from student_info where id=?",nativeQuery=true)
		public void deleteStudent(Long id);
		
		@Query(value="select * from student_info where name like 'v%'",nativeQuery=true)
		public List<StudentInfo> findAllStudentsByName();
		
		@Query(value="select * from student_info ",nativeQuery=true)
		public List<StudentInfo> findAllStudents();
}