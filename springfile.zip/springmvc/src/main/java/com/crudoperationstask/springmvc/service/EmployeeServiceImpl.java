package com.crudoperationstask.springmvc.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.crudoperationstask.springmvc.dto.EmployeeInterface;
import com.crudoperationstask.springmvc.model.EmployeeInfo;
import com.crudoperationstask.springmvc.repository.EmployeeRepository;

@Service
public  class EmployeeServiceImpl implements EmployeeInterface{

	@Autowired
	private EmployeeRepository employee;
	@Override
	public EmployeeInfo saveEmployee(EmployeeInfo info) {
	
		return employee.save(info);
	}

	@Override
	public EmployeeInfo updateEmployee(EmployeeInfo info) {
		
		return employee.save(info);
	}

	@Override
	public void deleteEmployee(Integer id) {
		employee.deleteById(id);
		
	}

	@Override
	public List<EmployeeInfo> findAllEmployees() {
		
		return (List<EmployeeInfo>)employee.findAll();
	}

//	@Override
//	public Integer max(Integer sal) {
//		return employee.max(sal);
//	}
	@Override
	public EmployeeInfo saveEmployee(ResponseEntity<String> info) {
		// TODO Auto-generated method stub
		return null;
	}

	

		
	}

