package com.crudoperationstask.springmvc.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crudoperationstask.springmvc.dto.EmployeeInterface;
import com.crudoperationstask.springmvc.model.ServiceStatus;
import com.crudoperationstask.springmvc.model.StudentInfo;
import com.crudoperationstask.springmvc.repository.StudentRepo;
import com.crudoperationstask.springmvc.security.EncryptDecryptAlgo;
import com.crudoperationstask.springmvc.service.StudentServiceImpl;




@RestController
@CrossOrigin("*")
public class StudentController {
	
	@Autowired
	private EmployeeInterface employeeInterface;
	
	@Autowired
	private StudentServiceImpl serviceimpl;
	
	@Autowired
	private StudentRepo studentRepo;
	
	   @Bean
	    public BCryptPasswordEncoder passwordEncoder() {
	        return new BCryptPasswordEncoder();
	    }

	
	//inserting into student table
	   @PostMapping("/saveStudent")
		public ServiceStatus saveStudent(@RequestBody @Validated StudentInfo info) { 
		   ServiceStatus service=new ServiceStatus(); 

					if(info.getAddress()==null) {
					service.setMessage("Address can not be empty");
					service.setStatus("Failure");
					service.setResult("Failed to sent ");
	                                                     return service;
			}

			if(info.getEmail()==null) {
				service.setMessage("Email can not be null");
				service.setStatus("Failure");
				service.setResult("Failed to sent ");
	                                       return service;
		            }	
			if(info.getName()==null) {
				service.setMessage("Name can not be empty");
				service.setStatus("Failure");
				service.setResult("Failed to sent ");
				return service;
			
			}
             info.getEmployeeinfo(); //geeting employee details
             serviceimpl.saveStudent(info);
		
             try {
            		String encoderPassword = EncryptDecryptAlgo.encrypt(info.getPassword());
            		 info.setPassword(encoderPassword);
            	} catch (Exception e) {
            		// TODO Auto-generated catch block
            		e.printStackTrace();
            	}
	     studentRepo.save(info);
	     
			service.setStatus("Sucessfull");
			service.setMessage("Student is aded succesfully");
			service.setResult("Details sent to database ");
			return service;
		
		
	}
	//get student byname
	@GetMapping("/getAllStudentsByName")
	public List<StudentInfo> findAllStudentsByName(@RequestParam String name) {
		
		return (List<StudentInfo>) serviceimpl.findAllStudentsByName();
		
	}
	//get all students
	@GetMapping("/getAllStudents")
	public List<StudentInfo> findAllStudents() {
		
		return (List<StudentInfo>) serviceimpl.findAllStudents();
		
	}
	//updating student details
	@PutMapping("/updateStudent")
	public StudentInfo updateStudent(@RequestBody StudentInfo info) {
		
		serviceimpl.updateStudent(info);
	    return info;
	}
	//delete student byId
	@DeleteMapping("/deleteStudent")
	public String deleteStudent(@RequestParam Long id) {
		serviceimpl.deleteStudent(id);
		return "student deleted";
		
	}
//	@GetMapping("/getMaxSalary")
//	public EmployeeInfo max() {
//		.max(Integer sal);
//		return info;
//		
//	}
}
